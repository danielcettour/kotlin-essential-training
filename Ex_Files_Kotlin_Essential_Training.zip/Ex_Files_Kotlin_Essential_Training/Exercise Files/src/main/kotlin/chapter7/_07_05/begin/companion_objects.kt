package chapter7._07_05.begin

class CantCreate constructor(val message: String) {
    fun showMessage() {
        println(message)
    }
}

fun main() {
}
