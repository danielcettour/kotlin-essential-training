package chapter7._07_01.begin

fun main() {
}
