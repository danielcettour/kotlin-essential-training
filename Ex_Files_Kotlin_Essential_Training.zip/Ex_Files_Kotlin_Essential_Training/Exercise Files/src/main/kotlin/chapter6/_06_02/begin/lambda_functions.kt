package chapter6._06_02.begin

fun main() {
    val lam: (Int, Int) -> Int = { a: Int, b: Int -> a + b }
}
