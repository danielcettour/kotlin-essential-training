package chapter6._06_01.begin

fun main() {
}
