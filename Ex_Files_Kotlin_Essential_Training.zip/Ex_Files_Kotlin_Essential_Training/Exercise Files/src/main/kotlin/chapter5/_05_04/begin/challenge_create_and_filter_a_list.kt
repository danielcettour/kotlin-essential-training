package chapter5._05_04.begin

import java.io.File

fun main() {
    val res = "./resources"
}
