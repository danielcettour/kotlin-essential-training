package chapter5._05_01.begin

fun main() {
}
