package chapter2._02_04.begin

fun main() {
}
