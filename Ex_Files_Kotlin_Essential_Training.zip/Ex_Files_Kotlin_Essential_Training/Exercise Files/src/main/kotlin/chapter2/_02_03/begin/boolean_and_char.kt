package chapter2._02_03.begin

fun firstOperand(): Boolean {
    println("firstOperand")
    return false;
}

fun secondOperand(): Boolean {
    println("secondOperand")
    return true;
}

fun main() {
//    demoBoolean()
//    demoChar()
}

private fun demoBoolean() {
}

private fun demoChar() {
}
