package chapter2._02_01.end

fun main() {
    var count: Int = 0
    val number: Int = 42

    val otherNumber = 43

    val myLong: Long = 3000000000L
    val myByte: Byte = 127
    val myShort: Short = 32767

    val myDouble: Double = 98.6
    val myFloat: Float = 12.2F
    val alsoDouble = 101.5

    val asInt = alsoDouble.toInt()
    val asFloat = myLong.toFloat()

    val maxInt = 2_147_483_648


}
