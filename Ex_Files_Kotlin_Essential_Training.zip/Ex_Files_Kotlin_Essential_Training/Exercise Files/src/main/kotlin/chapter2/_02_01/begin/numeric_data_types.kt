package chapter2._02_01.begin

fun main() {
}
