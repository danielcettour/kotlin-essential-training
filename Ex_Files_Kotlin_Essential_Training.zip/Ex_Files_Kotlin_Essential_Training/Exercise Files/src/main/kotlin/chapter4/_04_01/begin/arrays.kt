package chapter4._04_01.begin

data class Student(val firstName: String, val grade: Int)

fun main() {
}

fun fiver(index: Int): Int{
    return index * 5;
}
