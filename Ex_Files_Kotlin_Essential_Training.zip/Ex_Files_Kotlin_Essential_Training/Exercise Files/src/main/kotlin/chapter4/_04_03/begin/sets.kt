package chapter4._04_03.begin

fun main() {
}
