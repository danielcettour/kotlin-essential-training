package chapter4._04_02.begin

fun main() {
}

