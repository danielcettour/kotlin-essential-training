package chapter3._03_03.begin

enum class Suit {
    Club, Diamond, Heart, Spade
}

fun main() {
}
