package chapter3._03_05.begin

data class Person(var firstName: String, var lastName: String)

fun main() {
}
