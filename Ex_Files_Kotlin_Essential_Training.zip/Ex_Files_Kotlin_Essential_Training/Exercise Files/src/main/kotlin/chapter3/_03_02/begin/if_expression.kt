package chapter3._03_02.begin

fun main() {
}
