package chapter3._03_04.begin

fun main() {
}
