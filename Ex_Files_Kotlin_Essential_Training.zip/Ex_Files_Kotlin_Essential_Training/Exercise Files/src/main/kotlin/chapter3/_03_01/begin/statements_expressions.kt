package chapter3._03_01.begin

fun returnsNothing() {
    println("returnsNothing() function")
}

fun main() {
}
